var markerslon=new Array();
var markerslal=new Array();
var markers=new Array();
var marker;
var nb;
var map;
var myMenu = '<div>\
							<a href="#"><i id="home" class="material-icons">map</i></a>\
							<a href="#"><i id="boutique" class="material-icons">store</i></a>\
							<a href="#"><i id="cloud" class="material-icons">cloud</i></a>\
							<a href="#"><i id="annonces" class="material-icons">shopping_cart</i></a>\
							<a href="#"><i id="car" class="material-icons">directions_car</i></a>\
							<a href="#"><i id="camera" class="material-icons">camera_alt</i></a>\
							<a href="#"><i id="gesture" class="material-icons">local_library</i></a>\
							<a href="#"><i id="astuce" class="material-icons">feedback</i></a>\
						   </div>';
						   var myMenu1 = '<div>\
							<a href="#"><i id="home" class="material-icons">person</i></a>\
							<a href="#"><i class="material-icons">shopping_cart</i></a>\
							<a href="#"><i id="cloud" class="material-icons">directions_car</i></a>\
							<a href="#"><i id="call" class="material-icons">camera_alt</i></a>\
							<a href="#"><i id="mail" class="material-icons">mail_outline</i></a>\
							<a href="#"><i id="chat" class="material-icons">input</i></a>\
						   </div>';
	$('[name="demo"]').popup({

  content: myMenu,
  position: "right"

});
$('[name="demo1"]').popup({

  content: myMenu1,
  position: "left"

});
function init(){
       var url = "http://192.168.43.127/projects/app1/maps.php";
        $.getJSON(url, function(result) {
            console.log(result);
            $.each(result, function(i, field) {
			markerslon[i]=field.Longitude;
			markerslal[i]=field.Laltitude;
			var loc = new google.maps.LatLng(field.Laltitude, field.Longitude);
                var id = field.Longitude;
                var title = field.Nom_Boutique;
                var duration = field.appat;
                var price = field.Laltitude;
	/*if(i==0){
	marker = new Marker({
	map: map,
        position: new google.maps.LatLng(36.735766,10.201111)		
    });   
    // MAP - Place markers
	marker.setIcon("iconn.png");
    marker.setMap(map);
	}*/
				
		markers[i] = new google.maps.Marker({
        position: new google.maps.LatLng(field.Laltitude, field.Longitude),		
    });   
    // MAP - Place markers
	markers[i].setIcon("iconn.png");
    markers[i].setMap(map);			
				
				nb=i;
            });
        });
}
function myMap() {
var mapProp= {
    center:new google.maps.LatLng(36.735766,10.201111),
    zoom:12,
	mapTypeControl : false,
	zoomControl : false,
	streetViewControl : false,
	fullscreenControl : false
};
map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
}
function getPosition() {
    navigator.geolocation.getCurrentPosition(successPosition, failPosition);
}

//called when the position is successfully determined
function successPosition(position) {
    var long = position.coords.longitude;
    var lat = position.coords.latitude;
    var current = new google.maps.LatLng(lat, long);
    setloc(current, 12);
}

function failPosition(err) {
    alert('ERROR(' + err.code + '): ' + err.message);
    console.warn('ERROR(' + err.code + '): ' + err.message);
}

function setloc(loc, zoom) {
    map.setCenter(loc);
    map.setZoom(zoom);
}